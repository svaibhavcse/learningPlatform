import './App.css'
import React from 'react'
import Login from './components/login'
import { CreateUser } from './components/createUser';
import ResetPassword from './components/resetPassword';
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css'; 
import { Bucket } from './components/bucket'; 
import { Event } from './components/event';
export const App = () => {
  return (
    <>
     <BrowserRouter>
     <Bucket>
     <Routes>
      <Route path="/" element={<Login />}/>
      <Route path="/createuser" element={<CreateUser />}/>
      <Route path="/resetPassword/:email" element={<ResetPassword />}/>
      <Route path ="/event"element={<Event/>}/>
    </Routes>
    </Bucket>
    </BrowserRouter>
    </>
  )
}

export default App