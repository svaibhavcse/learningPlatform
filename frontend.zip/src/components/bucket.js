import React, { createContext, useContext, useState } from "react";
const supplier = createContext();

export const Bucket = (props) => {
    const [email, setEmail] = useState('');
    return (
        <>
        <supplier.Provider value={{setEmail,email}}>
            {props.children}
        </supplier.Provider>
        </>
      )
    }

export const useSupplier = () =>{ 
        return useContext(supplier);
    }
  

