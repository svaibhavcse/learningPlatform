import React, { useState } from 'react';
import { AdminNavbar } from './adminNavbar';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import CreateEventForm from './createEventForm';
import './styles/event.css'
import EventList from './eventList';
export const Event = () => {
  const [showModal, setShowModal] = useState(false);
  const handleShowModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);

  return (
    <div>
      <AdminNavbar />
      <div>
        <Button variant='outline-dark' style={{ width: "20%", borderRadius:"25px" }} onClick={handleShowModal}>
          Create Event
        </Button>
      </div>
      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Create Event</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <CreateEventForm />
        </Modal.Body>
      </Modal>
<EventList />
    </div>
  );
};
