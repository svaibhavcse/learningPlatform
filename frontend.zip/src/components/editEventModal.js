import React, { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';

const EditEventModal = ({ event, show, handleClose, handleEdit ,handleSaveChanges}) => {
  const [editedEvent, setEditedEvent] = useState({
    eventName: event.eventName,
    eventDescription: event.eventDescription,
    date: event.date,
    time: event.time,
    location: event.location,
    skillSet: event.skillSet,
    trainer: event.trainer,
    status: event.status
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedEvent({ ...editedEvent, [name]: value });
  };

  const handleSubmit = () => {
    handleEdit(event._id, editedEvent);
    handleSaveChanges(editedEvent)
    handleClose();
  };

  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Edit Event</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <form onSubmit={handleSubmit}>
          <label>
            Event Name:
            <input
              type="text"
              name="eventName"
              value={editedEvent.eventName}
              onChange={handleChange}
            />
          </label>
          <label>
            Event Description:
            <textarea
              name="eventDescription"
              value={editedEvent.eventDescription}
              onChange={handleChange}
            />
          </label>
          <label>
            Date:
            <input
              type="date"
              name="date"
              value={editedEvent.date}
              onChange={handleChange}
            />
          </label>
          <label>
            Time:
            <input
              type="time"
              name="time"
              value={editedEvent.time}
              onChange={handleChange}
            />
          </label>
          <label>
            Location:
            <input
              type="text"
              name="location"
              value={editedEvent.location}
              onChange={handleChange}
            />
          </label>
          <label>
            Trainer:
            <input
              type="text"
              name="trainer"
              value={editedEvent.trainer}
              onChange={handleChange}
            />
          </label>
          <label>
            Status:
            <input
              type="text"
              name="status"
              value={editedEvent.status}
              onChange={handleChange}
            />
          </label>
          <Button variant="primary" type="submit">
            Save Changes
          </Button>
        </form>
      </Modal.Body>
    </Modal>
  );
};

export default EditEventModal;
