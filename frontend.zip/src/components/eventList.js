import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import { ToastContainer, toast } from 'react-toastify';
import EditEventModal from './editEventModal';
const EventList = () => {
  const [events, setEvents] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editedEvent, setEditedEvent] = useState(null);

  const handleEdit = (event) => {
    setEditedEvent(event);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditedEvent(null);
  };

  // Function to handle deleting an event
  const handleDelete =async (eventId) => {
    try {
        // Send a DELETE request to the backend API endpoint for deleting events
        await axios.delete(`http://localhost:5000/events/${eventId}`);
        toast.success("Event deleted successfully")
        console.log('Event deleted successfully:', eventId);
        
      } catch (error) {
        toast.error("Error deleting event")
        console.error('Error deleting event:', error);
        
      }
    };

    const handleSaveChanges = async (updatedEvent) => {
        try {
          await axios.put(`http://localhost:5000/events/${updatedEvent._id}`, updatedEvent);
          // Optionally, update the events state to reflect the changes
        } catch (error) {
          console.error('Error saving changes:', error);
          // Handle errors (e.g., display an error message to the user)
        }
      };

  useEffect(() => {
    // Fetch events data from the backend when the component mounts
    const fetchEvents = async () => {
      try {
        const response = await axios.get('http://localhost:5000/events');
        setEvents(response.data);
      } catch (error) {
        console.error('Error fetching events:', error);
        // Add error handling logic (e.g., display an error message)
      }
    };
    fetchEvents();
  }, []); // Empty dependency array to run the effect only once when the component mounts

  return (
    <div>
     <ToastContainer position="top-right" autoClose={1500} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} draggable theme="colored"/>

      <h2>Events</h2>
      <div className="event-list">
        {/* Map through the events array and render a Card component for each event */}
        <div className="row">
        {events.map((event, index) => (
          <div key={index} className="col-md-6">
            <Card style={{ width: '100%', marginBottom: '1rem' }}>
              <Card.Body>
                <Card.Title>{event.eventName}</Card.Title>
                <Card.Subtitle className="mb-2 text-muted">Date: {event.date}</Card.Subtitle>
                <Card.Text style={{whiteSpace: "pre-line"}}>Description: {event.eventDescription}</Card.Text>
                <Card.Text>Trainer: {event.trainer}</Card.Text>
                <Card.Text>Time: {event.time}</Card.Text>
                <Card.Text>Location: {event.location}</Card.Text>
                <Card.Text>Skill Set: {event.skillSet.join(', ')}</Card.Text>
                <Card.Text>Status: {event.status}</Card.Text>
                {/* Edit Button */}
                <Button variant="outline-primary" style={{ borderRadius:"25px",width:"45%",marginRight:"10px" }} onClick={() => handleEdit(event)}>Edit</Button>
                {/* Delete Button */}
                <Button variant="outline-danger" style={{ borderRadius:"25px" ,width:"45%"}} onClick={() => handleDelete(event._id)}>Delete</Button>
              </Card.Body>
            </Card>
            {event && (
                <EditEventModal
                    event={event}
                    show={showModal}
                    handleClose={handleCloseModal}
                    handleEdit={handleEdit}
                    handleSaveChanges={handleSaveChanges}
                />
                )}
          </div>
          
        ))}
      </div>
      </div>
      
    </div>
  );
};

export default EventList;
